THIS DATAPACK WAS COMPILED USING ASSETS FROM SEVERAL OTHER CREATORS:

UltiMon
- Alolan Diglett (SpencyRock)
- Alolan Dugtrio (SpencyRock, Bruno22, and Spoon)
- Alolan Grimer (SpencyRock)
- Sunkern (CumuloWinter & Spoon)
- Sunflora (CumuloWinter & Spoon)
- Corsola (SpencyRock)
- Celebi (Spoon)
- Surskit (Spoon) [REPLACED WITH ACTUAL COBBLEMON ASSETS, TO FIND THE OLD VERSION, PLEASE DOWNLOAD A VERSION OF ULTIMON FOR COBBLEMON v1.3]
- Masquerain (Spoon) [REPLACED WITH ACTUAL COBBLEMON ASSETS, TO FIND THE OLD VERSION, PLEASE DOWNLOAD A VERSION OF ULTIMON FOR COBBLEMON v1.3]
- Zangoose (Spoon)
- Starly (Spoon) [REPLACED WITH ACTUAL COBBLEMON ASSETS, TO FIND THE OLD VERSION, PLEASE DOWNLOAD A VERSION OF ULTIMON FOR COBBLEMON v1.3]
- Staravia (Spoon) [REPLACED WITH ACTUAL COBBLEMON ASSETS, TO FIND THE OLD VERSION, PLEASE DOWNLOAD A VERSION OF ULTIMON FOR COBBLEMON v1.3]
- Staraptor (Spoon) [REPLACED WITH ACTUAL COBBLEMON ASSETS, TO FIND THE OLD VERSION, PLEASE DOWNLOAD A VERSION OF ULTIMON FOR COBBLEMON v1.3]
- Hippopotas (Spoon)
- Hippowdon (Spoon)
- Scraggy (CumuloWinter)
- Scrafty (CumuloWinter)
- Solosis (Bwavi & Wither_Scout)
- Duosion (Bwavi & Wither_Scout)
- Reuniclus (Bwavi & Wither_Scout)
- Swirlix (SpencyRock and Spoon)
- Slurpuff (SpencyRock and Spoon)

MoreMons (Bruno22)
- Heracross
- Ralts [REPLACED WITH ACTUAL COBBLEMON ASSETS, TO FIND THE OLD VERSION, PLEASE DOWNLOAD A VERSION OF ULTIMON FOR COBBLEMON v1.3]
- Kirlia [REPLACED WITH ACTUAL COBBLEMON ASSETS, TO FIND THE OLD VERSION, PLEASE DOWNLOAD A VERSION OF ULTIMON FOR COBBLEMON v1.3]
- Gardevoir [REPLACED WITH ACTUAL COBBLEMON ASSETS, TO FIND THE OLD VERSION, PLEASE DOWNLOAD A VERSION OF ULTIMON FOR COBBLEMON v1.3]
- Beldum [REPLACED WITH ACTUAL COBBLEMON ASSETS, TO FIND THE OLD VERSION, PLEASE DOWNLOAD A VERSION OF ULTIMON FOR COBBLEMON v1.3]
- Metang [REPLACED WITH ACTUAL COBBLEMON ASSETS, TO FIND THE OLD VERSION, PLEASE DOWNLOAD A VERSION OF ULTIMON FOR COBBLEMON v1.3]
- Metagross [REPLACED WITH ACTUAL COBBLEMON ASSETS, TO FIND THE OLD VERSION, PLEASE DOWNLOAD A VERSION OF ULTIMON FOR COBBLEMON v1.3]
- Croagunk
- Toxicroak
- Gallade [REPLACED WITH ACTUAL COBBLEMON ASSETS, TO FIND THE OLD VERSION, PLEASE DOWNLOAD A VERSION OF ULTIMON FOR COBBLEMON v1.3]
- Drillbur
- Excadrill
- Litwick [REPLACED WITH ACTUAL COBBLEMON ASSETS, TO FIND THE OLD VERSION, PLEASE DOWNLOAD A VERSION OF ULTIMON FOR COBBLEMON v1.3]
- Lampent [REPLACED WITH ACTUAL COBBLEMON ASSETS, TO FIND THE OLD VERSION, PLEASE DOWNLOAD A VERSION OF ULTIMON FOR COBBLEMON v1.3]
- Chandelure [REPLACED WITH ACTUAL COBBLEMON ASSETS, TO FIND THE OLD VERSION, PLEASE DOWNLOAD A VERSION OF ULTIMON FOR COBBLEMON v1.3]
- Larvesta
- Volcarona
- Dewpider
- Araquanid
- Guzzlord
- Dreepy
- Drakloak
- Dragapult
- Capsakid
- Scovillain
- Annihilape [REPLACED WITH ACTUAL COBBLEMON ASSETS, TO FIND THE OLD VERSION, PLEASE DOWNLOAD A VERSION OF ULTIMON FOR COBBLEMON v1.3]
- Iron Valiant

Buizel and Floatzel (spenny)
- Buizel [REPLACED WITH ACTUAL COBBLEMON ASSETS, TO FIND THE OLD VERSION, PLEASE DOWNLOAD A VERSION OF ULTIMON FOR COBBLEMON v1.3]
- Floatzel [REPLACED WITH ACTUAL COBBLEMON ASSETS, TO FIND THE OLD VERSION, PLEASE DOWNLOAD A VERSION OF ULTIMON FOR COBBLEMON v1.3]

HiddenMons (LegenTM)
- Togepi
- Togetic
- Mareep [REPLACED WITH ACTUAL COBBLEMON ASSETS, TO FIND THE OLD VERSION, PLEASE DOWNLOAD A VERSION OF ULTIMON FOR COBBLEMON v1.3]
- Flaaffy [REPLACED WITH ACTUAL COBBLEMON ASSETS, TO FIND THE OLD VERSION, PLEASE DOWNLOAD A VERSION OF ULTIMON FOR COBBLEMON v1.3]
- Ampharos [REPLACED WITH ACTUAL COBBLEMON ASSETS, TO FIND THE OLD VERSION, PLEASE DOWNLOAD A VERSION OF ULTIMON FOR COBBLEMON v1.3]
- Swablu
- Altaria
- Shuppet
- Banette
- Bagon
- Shelgon
- Salamence
- Togekiss
- Galarian Yamask
- Zygarde
- Minior
- Kartana
- Sinistea
- Polteagiest
- Snom
- Frosmoth
- Runerigus
- Tatsugiri [REMODEL]

DeCube's MoMonsPack (DeCube)
- Marill [REVISIONS BY REDRIIBON]
- Azumarill [REVISIONS BY REDRIIBON]
- Wingull [REPLACED WITH ACTUAL COBBLEMON ASSETS, TO FIND THE OLD VERSION, PLEASE DOWNLOAD A VERSION OF ULTIMON FOR COBBLEMON v1.3]
- Pelipper [REPLACED WITH ACTUAL COBBLEMON ASSETS, TO FIND THE OLD VERSION, PLEASE DOWNLOAD A VERSION OF ULTIMON FOR COBBLEMON v1.3]
- Makuhita
- Hariyama
- Azurill [REVISIONS BY REDRIIBON]
- Trapinch [REVISIONS BY SPENCYROCK]
- Vibrava [REVISIONS BY SPENCYROCK]
- Flygon [REVISIONS BY SPENCYROCK]
- Spheal
- Sealeo
- Walrein
- Iron Hands

TerastalMons (GenotypeXD)
-Terapagos

BattleBond Pack (GenotypeXD)
- Ash Greninja

GenoMons (GenotypeXD)
- Charizard [REMODEL]
- Alolan Muk
- Hisuian Voltorb
- Hisuian Electrode
- Articuno [REMODEL]
- Galarian Articuno
- Zapdos [REMODEL]
- Galarian Zapdos
- Moltres [REMODEL]
- Galarian Moltres
- Delibird
- Hawlucha
- Tapu-Koko
- Toedscool
- Toedscruel
- Orthworm
- Frigibax
- Arctibax
- Baxcalibur
- Chi-Yu
- Bloodmoon Ursaluna

PigeonPack (El Pigeon)
- Petilil
- Lilligant
- Hisuian Lilligant
- Volcanion
- Fomantis
- Lurantis
- Blipbug
- Dottler
- Orbeetle

MissingMons (RedRibbon)
- Gengar [ADDITIONAL ANIMATION]
- Alolan Marowak
- Sentret
- Furret
- Galarian Corsola
- Shellos
- Gastrodon
- Shaymin
- Munna
- Musharna
- Minccino
- Cinccino
- Skiddo
- Gogoat
- Rockruff
- Lycanroc
- Sandygast
- Palossand
- Togedemaru
- Cramorant
- Cursola
- Morpeko
- Finizen
- Palafin
- Veluza
- Flutter Mane
- Gimmighoul
- Gholdengo
- Poltchageist
- Sinistcha
- Pecharunt

Hisuian Forms For Cobblemon (Platinum Pancakes)
- Hisuian Typhlosion
- Hisuian Samurott

Special Thanks
- Frank the Farmer: Vital for troubleshooting, fixing bugs, and providing invaluable support during compilation and development of UltiMon's assets.